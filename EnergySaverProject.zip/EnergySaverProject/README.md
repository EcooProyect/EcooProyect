# EnergySaverProject

## Descripción
EnergySaverProject es un software diseñado para monitorear la actividad de un equipo y, después de un tiempo de inactividad, apagarlo de manera segura. Su objetivo principal es ahorrar energía y proteger los dispositivos de posibles daños por sobrecalentamiento o uso prolongado.

## Caracteristicas
- Monitoreo continuo de la actividad del equipo.
- Apagado seguro tras un periodo de inactividad.
- Integracion con sensores para detectar presencia (opcional).
- Configuracion personalizable para diferentes entornos y requisitos.

## Estructura del proyecto

