# Instrucciones de Instalación

1. Clona el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/EnergySaverProject.git
   cd EnergySaverProject
   