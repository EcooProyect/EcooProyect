# Requisitos del Proyecto

## Dependencias del sistema
- Python 3.8 o superior
- Git
- Paquetes adicionales de Python listados en requirements.txt

## Dependencias de Python
- random
- logging
# Requisitos del Sistema
- Sensores térmicos compatibles.
- Computadora con capacidad para ejecutar el programa.
- Conexión a la red eléctrica con controladores.

# Requisitos del Software
- Python 3.x
- Librerías necesarias (consultar `requirements.txt`).
pip install -r requirements.txt
